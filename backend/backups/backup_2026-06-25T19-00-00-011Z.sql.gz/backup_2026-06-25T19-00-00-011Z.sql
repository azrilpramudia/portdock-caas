--
-- PostgreSQL database dump
--

\restrict GWDDfFyIoBLEyzLkdmBvDMY8VXaIWUuTqFrREBFZyKJ2FAddHaGwgsvqopZMiB2

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AppTemplate; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."AppTemplate" AS ENUM (
    'NIXPACKS',
    'STATIC_NGINX',
    'STATIC_APACHE',
    'PHP_APACHE'
);


ALTER TYPE public."AppTemplate" OWNER TO portdock;

--
-- Name: ContainerStatus; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."ContainerStatus" AS ENUM (
    'RUNNING',
    'STOPPED',
    'BUILDING',
    'ERROR',
    'REMOVING'
);


ALTER TYPE public."ContainerStatus" OWNER TO portdock;

--
-- Name: DatabaseType; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."DatabaseType" AS ENUM (
    'POSTGRESQL',
    'MYSQL',
    'REDIS',
    'MONGODB'
);


ALTER TYPE public."DatabaseType" OWNER TO portdock;

--
-- Name: DeploymentType; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."DeploymentType" AS ENUM (
    'ZIP',
    'GITHUB',
    'DOCKERFILE'
);


ALTER TYPE public."DeploymentType" OWNER TO portdock;

--
-- Name: ProjectStatus; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."ProjectStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'BUILDING',
    'FAILED'
);


ALTER TYPE public."ProjectStatus" OWNER TO portdock;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."Role" AS ENUM (
    'USER',
    'ADMIN'
);


ALTER TYPE public."Role" OWNER TO portdock;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO portdock;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.activity_logs (
    id text NOT NULL,
    user_id text NOT NULL,
    project_id text,
    action text NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status text DEFAULT 'Success'::text NOT NULL,
    ip_address text
);


ALTER TABLE public.activity_logs OWNER TO portdock;

--
-- Name: containers; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.containers (
    id text NOT NULL,
    project_id text NOT NULL,
    docker_container_id text,
    name text NOT NULL,
    image_name text NOT NULL,
    image_tag text DEFAULT 'latest'::text NOT NULL,
    subdomain text,
    internal_port integer NOT NULL,
    host_port integer,
    status public."ContainerStatus" DEFAULT 'STOPPED'::public."ContainerStatus" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    cpu_limit double precision,
    memory_limit integer,
    restart_policy text DEFAULT 'unless-stopped'::text NOT NULL,
    volume_mount_path text
);


ALTER TABLE public.containers OWNER TO portdock;

--
-- Name: managed_databases; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.managed_databases (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    type public."DatabaseType" NOT NULL,
    version text DEFAULT 'latest'::text NOT NULL,
    db_user text,
    db_password text,
    db_name text,
    docker_container_id text,
    internal_port integer NOT NULL,
    host_port integer NOT NULL,
    status public."ContainerStatus" DEFAULT 'STOPPED'::public."ContainerStatus" NOT NULL,
    memory_limit integer DEFAULT 512,
    cpu_limit double precision DEFAULT 0.5,
    volume_name text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.managed_databases OWNER TO portdock;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.projects (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    deployment_type public."DeploymentType" NOT NULL,
    repository_url text,
    domain text,
    status public."ProjectStatus" DEFAULT 'INACTIVE'::public."ProjectStatus" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    env_vars jsonb,
    template_id public."AppTemplate" DEFAULT 'NIXPACKS'::public."AppTemplate" NOT NULL
);


ALTER TABLE public.projects OWNER TO portdock;

--
-- Name: terminal_logs; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.terminal_logs (
    id text NOT NULL,
    user_id text NOT NULL,
    project_id text,
    command text NOT NULL,
    output text,
    executed_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.terminal_logs OWNER TO portdock;

--
-- Name: users; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "githubToken" text,
    "githubUsername" text,
    "sshPrivateKey" text,
    "sshPublicKey" text,
    role public."Role" DEFAULT 'USER'::public."Role" NOT NULL
);


ALTER TABLE public.users OWNER TO portdock;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
32eb3268-fb8f-4da7-b701-e991ba36f03e	79744e9b724b7b6b14f03d9fd0df6ba67afd65c503f1079ce7dd5cc1525adbd7	2026-06-15 19:59:25.715602+00	20260611195656_init	\N	\N	2026-06-15 19:59:25.582944+00	1
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.activity_logs (id, user_id, project_id, action, description, created_at, status, ip_address) FROM stdin;
cmqti3fk8000121dcjhorr1tg	cmqrzi3w20000iodcbizx8w8j	cmqti3fjd000021dcn1feu71y	PROJECT_CREATED	Project "testing" created	2026-06-25 12:51:03.176	Success	\N
cmqti3fn2000221dcl4sxr2mk	cmqrzi3w20000iodcbizx8w8j	cmqti3fjd000021dcn1feu71y	DEPLOYMENT_STARTED	Deployment started for "testing" via ZIP	2026-06-25 12:51:03.278	Success	\N
cmqti3j8i000421dcvxd04cyd	cmqrzi3w20000iodcbizx8w8j	cmqti3fjd000021dcn1feu71y	DEPLOYMENT_SUCCESS	Deployment succeeded for "testing"	2026-06-25 12:51:07.938	Success	\N
cmqtq4owx00013odcech5ipyn	cmqtq4ojw00003odcvi7bopj5	\N	REGISTER	User registered	2026-06-25 16:35:58.881	Success	::1
cmqts0xis000175dcratc5dqu	cmqts0xh0000075dcoarku750	\N	REGISTER	User registered	2026-06-25 17:29:02.644	Success	::1
cmqrzi3ws0001iodckf4ztmcn	cmqrzi3w20000iodcbizx8w8j	\N	REGISTER	User registered	2026-06-24 11:22:49.036	Success	::1
cmqtq5run00023odc4vuyqcax	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-25 16:36:49.343	Success	::1
cmqts2dnd000275dci53k90xj	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-25 17:30:10.201	Success	::1
cmqrziino0003iodcwlauzd49	cmqrzi3w20000iodcbizx8w8j	cmqrziin40002iodcby3vy71b	PROJECT_CREATED	Project "testing" created	2026-06-24 11:23:08.148	Success	\N
cmqrziipr0004iodcr9b77bqs	cmqrzi3w20000iodcbizx8w8j	cmqrziin40002iodcby3vy71b	DEPLOYMENT_STARTED	Deployment started for "testing" via ZIP	2026-06-24 11:23:08.224	Success	\N
cmqrzil1m0006iodcvdkoy7vj	cmqrzi3w20000iodcbizx8w8j	cmqrziin40002iodcby3vy71b	DEPLOYMENT_SUCCESS	Deployment succeeded for "testing"	2026-06-24 11:23:11.242	Success	\N
cmqtqr0x00001hedc1up2g7pw	cmqtq4ojw00003odcvi7bopj5	cmqtqr0w60000hedcsby1e13r	PROJECT_CREATED	Project "develop" created	2026-06-25 16:53:20.869	Success	\N
cmqtqr15m0002hedcvv1qutqv	cmqtq4ojw00003odcvi7bopj5	cmqtqr0w60000hedcsby1e13r	DEPLOYMENT_STARTED	Deployment started for "develop" via ZIP	2026-06-25 16:53:21.178	Success	\N
cmqtswf1z0001h8dczv5zwls5	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test validasi" created	2026-06-25 17:53:31.703	Success	\N
cmqtqr6pn0004hedckyzvbhhy	cmqtq4ojw00003odcvi7bopj5	cmqtqr0w60000hedcsby1e13r	DEPLOYMENT_SUCCESS	Deployment succeeded for "develop"	2026-06-25 16:53:28.379	Success	\N
cmqtsx4mo0002h8dcc6o050rq	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-06-25 17:54:04.848	Success	\N
\.


--
-- Data for Name: containers; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.containers (id, project_id, docker_container_id, name, image_name, image_tag, subdomain, internal_port, host_port, status, created_at, updated_at, cpu_limit, memory_limit, restart_policy, volume_mount_path) FROM stdin;
cmqrzil1f0005iodcsr8dib94	cmqrziin40002iodcby3vy71b	1f3781a6f69c5ba89f60b58d9358bbb4e962d4b540abb2bd3b614c87a5cf5f07	testing-1782300191233	portdock-cmqrziin40002iodcby3vy71b	v1782300188284	\N	3000	8000	RUNNING	2026-06-24 11:23:11.235	2026-06-24 11:23:11.235	0.5	512	unless-stopped	\N
cmqti3j7u000321dcw6i5nayk	cmqti3fjd000021dcn1feu71y	47112bbf253fa3dba91f3385a44375ff9e5cbbfe030afcf31a056d7380783872	testing-1782391867881	portdock-cmqti3fjd000021dcn1feu71y	v1782391863408	\N	3000	8001	RUNNING	2026-06-25 12:51:07.914	2026-06-25 12:51:07.914	0.5	512	unless-stopped	\N
cmqtqr6p50003hedc2bbxb86h	cmqtqr0w60000hedcsby1e13r	e99090806f724df82603b2bb92504f99d09d11a09693316585474f63be2741b3	develop-1782406408357	portdock-cmqtqr0w60000hedcsby1e13r	v1782406401228	\N	3000	8002	RUNNING	2026-06-25 16:53:28.361	2026-06-25 16:53:28.361	0.5	512	unless-stopped	\N
\.


--
-- Data for Name: managed_databases; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.managed_databases (id, user_id, name, type, version, db_user, db_password, db_name, docker_container_id, internal_port, host_port, status, memory_limit, cpu_limit, volume_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.projects (id, user_id, name, description, deployment_type, repository_url, domain, status, created_at, updated_at, env_vars, template_id) FROM stdin;
cmqrziin40002iodcby3vy71b	cmqrzi3w20000iodcbizx8w8j	testing	\N	ZIP	\N	testing.portdock.my.id	ACTIVE	2026-06-24 11:23:08.128	2026-06-24 11:23:11.239	\N	NIXPACKS
cmqti3fjd000021dcn1feu71y	cmqrzi3w20000iodcbizx8w8j	testing	\N	ZIP	\N	testing-4d28.portdock.my.id	ACTIVE	2026-06-25 12:51:03.145	2026-06-25 12:51:07.929	\N	NIXPACKS
cmqtqr0w60000hedcsby1e13r	cmqtq4ojw00003odcvi7bopj5	develop	\N	ZIP	\N	develop.portdock.my.id	ACTIVE	2026-06-25 16:53:20.838	2026-06-25 16:53:28.375	\N	NIXPACKS
\.


--
-- Data for Name: terminal_logs; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.terminal_logs (id, user_id, project_id, command, output, executed_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.users (id, name, email, password, created_at, updated_at, "githubToken", "githubUsername", "sshPrivateKey", "sshPublicKey", role) FROM stdin;
cmqrzi3w20000iodcbizx8w8j	panjul	panjul@gmail.com	$2b$12$4R7VFQU2pdwCXzc2zgBU5eMbMzyyE1s.06VRcjbn2yOev6wpD9IXm	2026-06-24 11:22:49.01	2026-06-24 11:22:49.01	\N	\N	\N	\N	USER
cmqtq4ojw00003odcvi7bopj5	develop	develop@support.com	$2b$12$RMYHI444xQ9YJnVBnsg9vOfqFRBLCesCsbz3kC8SOoljhZuwXi6bS	2026-06-25 16:35:58.412	2026-06-25 16:35:58.412	\N	\N	\N	\N	ADMIN
cmqts0xh0000075dcoarku750	testing	test@gmail.com	$2b$12$o5rPBy29BVP.VQAsygK7A.vgXzYa0qpAXt8hFQmdRRggz5MGwmKN2	2026-06-25 17:29:02.581	2026-06-25 17:29:02.581	\N	\N	\N	\N	USER
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: containers containers_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.containers
    ADD CONSTRAINT containers_pkey PRIMARY KEY (id);


--
-- Name: managed_databases managed_databases_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.managed_databases
    ADD CONSTRAINT managed_databases_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: terminal_logs terminal_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.terminal_logs
    ADD CONSTRAINT terminal_logs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: containers_docker_container_id_key; Type: INDEX; Schema: public; Owner: portdock
--

CREATE UNIQUE INDEX containers_docker_container_id_key ON public.containers USING btree (docker_container_id);


--
-- Name: managed_databases_docker_container_id_key; Type: INDEX; Schema: public; Owner: portdock
--

CREATE UNIQUE INDEX managed_databases_docker_container_id_key ON public.managed_databases USING btree (docker_container_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: portdock
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: activity_logs activity_logs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: containers containers_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.containers
    ADD CONSTRAINT containers_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: managed_databases managed_databases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.managed_databases
    ADD CONSTRAINT managed_databases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: terminal_logs terminal_logs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.terminal_logs
    ADD CONSTRAINT terminal_logs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: terminal_logs terminal_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.terminal_logs
    ADD CONSTRAINT terminal_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict GWDDfFyIoBLEyzLkdmBvDMY8VXaIWUuTqFrREBFZyKJ2FAddHaGwgsvqopZMiB2

