--
-- PostgreSQL database dump
--

\restrict qdBbjToHodMD6e03lnAqTsvWR75FWPbPG4VLIyxDlgxocWbuNZuOPH1RK4aEgg7

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AppTemplate; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."AppTemplate" AS ENUM (
    'NIXPACKS',
    'STATIC_NGINX',
    'STATIC_APACHE',
    'PHP_APACHE'
);


ALTER TYPE public."AppTemplate" OWNER TO portdock;

--
-- Name: ContainerStatus; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."ContainerStatus" AS ENUM (
    'RUNNING',
    'STOPPED',
    'BUILDING',
    'ERROR',
    'REMOVING'
);


ALTER TYPE public."ContainerStatus" OWNER TO portdock;

--
-- Name: DatabaseType; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."DatabaseType" AS ENUM (
    'POSTGRESQL',
    'MYSQL',
    'REDIS',
    'MONGODB'
);


ALTER TYPE public."DatabaseType" OWNER TO portdock;

--
-- Name: DeploymentType; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."DeploymentType" AS ENUM (
    'ZIP',
    'GITHUB',
    'DOCKERFILE'
);


ALTER TYPE public."DeploymentType" OWNER TO portdock;

--
-- Name: ProjectStatus; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."ProjectStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'BUILDING',
    'FAILED'
);


ALTER TYPE public."ProjectStatus" OWNER TO portdock;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."Role" AS ENUM (
    'USER',
    'ADMIN'
);


ALTER TYPE public."Role" OWNER TO portdock;

--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: portdock
--

CREATE TYPE public."UserStatus" AS ENUM (
    'ACTIVE',
    'SUSPENDED'
);


ALTER TYPE public."UserStatus" OWNER TO portdock;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO portdock;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.activity_logs (
    id text NOT NULL,
    user_id text NOT NULL,
    project_id text,
    action text NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status text DEFAULT 'Success'::text NOT NULL,
    ip_address text
);


ALTER TABLE public.activity_logs OWNER TO portdock;

--
-- Name: containers; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.containers (
    id text NOT NULL,
    project_id text NOT NULL,
    docker_container_id text,
    name text NOT NULL,
    image_name text NOT NULL,
    image_tag text DEFAULT 'latest'::text NOT NULL,
    subdomain text,
    internal_port integer NOT NULL,
    host_port integer,
    status public."ContainerStatus" DEFAULT 'STOPPED'::public."ContainerStatus" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    cpu_limit double precision,
    memory_limit integer,
    restart_policy text DEFAULT 'unless-stopped'::text NOT NULL,
    volume_mount_path text
);


ALTER TABLE public.containers OWNER TO portdock;

--
-- Name: deployments; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.deployments (
    id text NOT NULL,
    project_id text NOT NULL,
    status text DEFAULT 'In Progress'::text NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ended_at timestamp(3) without time zone,
    domain text,
    commit_hash text
);


ALTER TABLE public.deployments OWNER TO portdock;

--
-- Name: managed_databases; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.managed_databases (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    type public."DatabaseType" NOT NULL,
    version text DEFAULT 'latest'::text NOT NULL,
    db_user text,
    db_password text,
    db_name text,
    docker_container_id text,
    internal_port integer NOT NULL,
    host_port integer NOT NULL,
    status public."ContainerStatus" DEFAULT 'STOPPED'::public."ContainerStatus" NOT NULL,
    memory_limit integer DEFAULT 512,
    cpu_limit double precision DEFAULT 0.5,
    volume_name text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.managed_databases OWNER TO portdock;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.projects (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    deployment_type public."DeploymentType" NOT NULL,
    repository_url text,
    domain text,
    status public."ProjectStatus" DEFAULT 'INACTIVE'::public."ProjectStatus" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    env_vars jsonb,
    template_id public."AppTemplate" DEFAULT 'NIXPACKS'::public."AppTemplate" NOT NULL,
    branch text,
    build_command text,
    start_command text,
    domain_expires_at timestamp(3) without time zone,
    ssl_expires_at timestamp(3) without time zone
);


ALTER TABLE public.projects OWNER TO portdock;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    user_id text NOT NULL,
    ip_address text,
    user_agent text,
    last_active timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sessions OWNER TO portdock;

--
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.system_metrics (
    id text NOT NULL,
    cpu double precision NOT NULL,
    ram double precision NOT NULL,
    disk double precision,
    "networkOut" double precision,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.system_metrics OWNER TO portdock;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.system_settings (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.system_settings OWNER TO portdock;

--
-- Name: terminal_logs; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.terminal_logs (
    id text NOT NULL,
    user_id text NOT NULL,
    project_id text,
    command text NOT NULL,
    output text,
    executed_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.terminal_logs OWNER TO portdock;

--
-- Name: users; Type: TABLE; Schema: public; Owner: portdock
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "githubToken" text,
    "githubUsername" text,
    "sshPrivateKey" text,
    "sshPublicKey" text,
    role public."Role" DEFAULT 'USER'::public."Role" NOT NULL,
    last_login timestamp(3) without time zone,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    is_two_factor_enabled boolean DEFAULT false NOT NULL,
    lockout_until timestamp(3) without time zone,
    two_factor_secret text
);


ALTER TABLE public.users OWNER TO portdock;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
32eb3268-fb8f-4da7-b701-e991ba36f03e	79744e9b724b7b6b14f03d9fd0df6ba67afd65c503f1079ce7dd5cc1525adbd7	2026-06-15 19:59:25.715602+00	20260611195656_init	\N	\N	2026-06-15 19:59:25.582944+00	1
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.activity_logs (id, user_id, project_id, action, description, created_at, status, ip_address) FROM stdin;
cmqtq4owx00013odcech5ipyn	cmqtq4ojw00003odcvi7bopj5	\N	REGISTER	User registered	2026-06-25 16:35:58.881	Success	::1
cmqtvf76j00013idcoafwe3qg	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test-port" created	2026-06-25 19:04:07.195	Success	\N
cmqtvf79o00023idcca09v4ut	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-port" via ZIP	2026-06-25 19:04:07.308	Success	\N
cmqtvf9rj00043idcwdzvuvem	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "test-port"	2026-06-25 19:04:10.543	Success	\N
cmqwkmzdf0000t5dcq6fzwrra	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-27 16:25:33.076	Success	::1
cmqwncwsq0004t5dcfz3m7qz4	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-27 17:41:42.026	Success	::1
cmqtvmm8n0007ijdcj7gdvss8	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test-port" created	2026-06-25 19:09:53.303	Success	\N
cmqtvmm9o0008ijdc3riwoobe	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-port" via ZIP	2026-06-25 19:09:53.34	Success	\N
cmqtvmo97000aijdcw2qoudpr	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "test-port"	2026-06-25 19:09:55.915	Success	\N
cmqwp5oeo00000adcwe5d6ah7	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_PORT_REMOVED	Removed external port for container "test-port-1782414595902"	2026-06-27 18:32:03.792	Success	::1
cmqwq8h0p0000y7dckcqstrlt	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESOURCES_UPDATED	Updated resources for container "test-port-1782414595902" (RAM: 512MB, CPU: 1 Cores)	2026-06-27 19:02:13.802	Success	::1
cmqwsos7j000py7dc1g2cfgdk	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-static-nginx" via ZIP	2026-06-27 20:10:54.031	Success	::1
cmqwsov3h000ry7dchy7n4ltr	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "test-static-nginx"	2026-06-27 20:10:57.773	Success	::1
cmqwtn8jd0000djdczavdxp4s	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-06-27 20:37:41.497	Success	::1
cmqwt0d5a00055jdc40tihvts	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "static-nginx-web" created	2026-06-27 20:19:54.382	Success	::1
cmqwt0d6l00065jdctm2xf2of	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "static-nginx-web" via ZIP	2026-06-27 20:19:54.429	Success	::1
cmqwt0fib00085jdcue3peir2	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "static-nginx-web"	2026-06-27 20:19:57.443	Success	::1
cmqwqi3y70004y7dcdn0alviw	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_PORT_ALLOCATED	Allocated external port 19002 for container "develop-1782406408357"	2026-06-27 19:09:43.423	Success	::1
cmqwqi7mu0005y7dcose9n4ct	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "develop-1782406408357" restarted	2026-06-27 19:09:48.198	Success	::1
cmqzezl3y0002m2dcc9zo3fmf	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-29 16:10:41.95	Success	::1
cmqzg0qmn0003w8dcl6hjftc7	cmqzg0qll0002w8dcorklsynq	\N	REGISTER	User registered	2026-06-29 16:39:35.375	Success	::1
cmr2kbwg600007bdc10jfxy8f	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-07-01 21:03:33.126	Success	::1
cmqzd2en700094zdc5ekzcysi	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-code" via ZIP	2026-06-29 15:16:54.307	Success	::1
cmqzd2fj8000b4zdcg8sqh8hy	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "test-code"	2026-06-29 15:16:55.46	Success	::1
cmqzd2mou000c4zdcxxnnshkx	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-06-29 15:17:04.734	Success	::1
cmrac727m0000sbdc3xqfg8g4	cmqzg0qll0002w8dcorklsynq	\N	LOGIN	User logged in	2026-07-07 07:37:59.794	Success	::1
cmrfzobei00014kdcvp71d9g3	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "hello" created	2026-07-11 06:34:06.907	Success	::1
cmrfzobh400024kdc7ban1546	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "hello" via ZIP	2026-07-11 06:34:07	Success	::1
cmrg01kym000d4kdcooc3rqjp	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_PORT_ALLOCATED	Allocated external port 19501 for container "testing-1783752192129"	2026-07-11 06:44:25.822	Success	::1
cmrg1nsku000m4kdceorxtllq	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-11 07:29:41.742	Success	::1
cmrcbmonx0001widccgxfct17	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "html-test" created	2026-07-08 16:57:41.469	Success	::1
cmrcbmops0002widcvlz6vipj	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "html-test" via ZIP	2026-07-08 16:57:41.536	Success	::1
cmrcbmpa20005widcauty68tn	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "html-test"	2026-07-08 16:57:42.266	Success	::1
cmqwu3xd7000hdjdcx0f5sfi2	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "php-apache"	2026-06-27 20:50:40.171	Success	::1
cmqwtpndf0008djdcm0ookw96	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "static-apache" created	2026-06-27 20:39:34.035	Success	::1
cmqwtpne80009djdciw41uox1	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "static-apache" via ZIP	2026-06-27 20:39:34.064	Success	::1
cmqwujvhh0003fgdc2e7gihsi	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESOURCES_UPDATED	Updated resources for container "static-apache-1782592788280" (RAM: 256MB, CPU: 0.25 Cores)	2026-06-27 21:03:04.229	Success	::1
cmqwrmwvf000ay7dc879y8wj4	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "testing-dockerfile" created	2026-06-27 19:41:27.147	Success	::1
cmqwrmwx7000by7dc0faj3j4b	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "testing-dockerfile" via Custom Dockerfile	2026-06-27 19:41:27.211	Success	::1
cmqwrmz8j000dy7dc5ox9djgn	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Custom Dockerfile deployment completed successfully for "testing-dockerfile"	2026-06-27 19:41:30.212	Success	::1
cmqzbadb80000x6dc6ny0npb4	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_PORT_ALLOCATED	Allocated external port 19001 for container "testing-dockerfile-1782589290194"	2026-06-29 14:27:06.596	Success	::1
cmqtq5run00023odc4vuyqcax	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-25 16:36:49.343	Success	::1
cmqts2dnd000275dci53k90xj	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-25 17:30:10.201	Success	::1
cmqtvkju00000ijdci39v5m29	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_DELETED	Container "test-port-1782414250523" deleted	2026-06-25 19:08:16.872	Success	\N
cmqtvl15i0001ijdcm4ubsvon	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-port" via ZIP	2026-06-25 19:08:39.318	Success	\N
cmqtvl4360003ijdcwa34pr33	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "test-port"	2026-06-25 19:08:43.122	Success	\N
cmqtw1a0p0000epdcmqvma1ds	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_STOPPED	Container "test-port-1782414595902" stopped	2026-06-25 19:21:17.305	Success	::1
cmqwohivy0000bkdc3mkbg5pl	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_PORT_ALLOCATED	Allocated external port 19100 for container "test-port-1782414595902"	2026-06-27 18:13:16.894	Success	::1
cmqwpc7ri0000xpdchldgwbiu	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "test-port-1782414595902" restarted	2026-06-27 18:37:08.814	Success	::1
cmqwq909y0001y7dcjtdt7fv9	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESOURCES_UPDATED	Updated resources for container "test-port-1782414595902" (RAM: 512MB, CPU: 1 Cores)	2026-06-27 19:02:38.758	Success	::1
cmqwsvv070000brdc3g1hf9if	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_DELETED	Container "test-static-nginx-1782591057762" deleted	2026-06-27 20:16:24.248	Success	::1
cmqwt3vxh000a5jdce9eiezbd	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "static-apache-web" created	2026-06-27 20:22:38.693	Success	::1
cmqwt3vz0000b5jdc0gys7wkm	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "static-apache-web" via ZIP	2026-06-27 20:22:38.748	Success	::1
cmqwt3y03000d5jdcz5ejo1wg	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "static-apache-web"	2026-06-27 20:22:41.379	Success	::1
cmqwtncf90001djdcay5zchuf	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-06-27 20:37:46.533	Success	::1
cmqwqkzih0006y7dceiorxkto	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "develop-1782406408357" restarted	2026-06-27 19:11:57.641	Success	::1
cmqwuqcmc0009fgdcwf9mgfnr	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-27 21:08:06.372	Success	::1
cmqzfbp2y0000r4dc1mcbub07	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-29 16:20:06.97	Success	::1
cmqzg17sb0004w8dc4llubc5q	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-29 16:39:57.611	Success	::1
cmqws2k45000fy7dckntsgbm4	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test-zip" created	2026-06-27 19:53:37.109	Success	::1
cmqws2k5h000gy7dch4og5c0w	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-zip" via ZIP	2026-06-27 19:53:37.157	Success	::1
cmqws2mac000iy7dcl94khcn7	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "test-zip"	2026-06-27 19:53:39.924	Success	::1
cmrac8acg0002sbdcbl1p14ag	cmqzg0qll0002w8dcorklsynq	cmrac8ac20001sbdcjtm15ofh	PROJECT_CREATED	Project "html" created	2026-07-07 07:38:56.992	Success	::1
cmrac8ae60003sbdc4lz4jpg2	cmqzg0qll0002w8dcorklsynq	cmrac8ac20001sbdcjtm15ofh	DEPLOYMENT_STARTED	Deployment started for "html" via ZIP	2026-07-07 07:38:57.054	Success	::1
cmrac8b3y0005sbdc5sebkhtt	cmqzg0qll0002w8dcorklsynq	cmrac8ac20001sbdcjtm15ofh	DEPLOYMENT_SUCCESS	Deployment succeeded for "html"	2026-07-07 07:38:57.982	Success	::1
cmrfzogzm00054kdcuswc1nzb	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "hello"	2026-07-11 06:34:14.146	Success	::1
cmrfzooxt00064kdc0mnj9izg	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-11 06:34:24.449	Success	::1
cmrg02orn000e4kdcug90tddm	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "testing-1783752192129" restarted	2026-07-11 06:45:17.411	Success	::1
cmrceo49v00005udcq0evza47	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESOURCES_UPDATED	Updated resources for container "html-test-1783529862231" (RAM: 256MB, CPU: 0.5 Cores)	2026-07-08 18:22:47.207	Success	\N
cmrg1o06s000n4kdcuwcux5ll	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-11 07:29:51.604	Success	::1
cmqwu94gu0000fgdc9gfxbl1a	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESOURCES_UPDATED	Updated resources for container "php-apache-1782593440154" (RAM: 128MB, CPU: 1 Cores)	2026-06-27 20:54:42.655	Success	::1
cmqzdj49h0000r3dcky971a5p	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_UPDATED	Project "php-apache" updated	2026-06-29 15:29:54.006	Success	::1
cmrg1o2vy000o4kdct07aav5d	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-11 07:29:55.102	Success	::1
cmqwtpydj000bdjdc7b1n8y9a	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "static-apache"	2026-06-27 20:39:48.295	Success	::1
cmqzbagih0001x6dcmgtm11kv	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "testing-dockerfile-1782589290194" restarted	2026-06-29 14:27:10.745	Success	::1
cmrlsrzhm0001cedcc7u56vp6	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in with 2FA	2026-07-15 08:07:37.834	Success	::1
cmrlv2a8q000773dcnhxdwy78	cmqtq4ojw00003odcvi7bopj5	\N	GENERATE_SSH_KEY	User generated a new SSH key	2026-07-15 09:11:37.562	Success	::1
cmrlv2gr9000873dcia4jf31i	cmqtq4ojw00003odcvi7bopj5	\N	GENERATE_SSH_KEY	User generated a new SSH key	2026-07-15 09:11:46.005	Success	::1
cmrmec1gw0000modc0uw3kuf5	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-07-15 18:11:05.456	Success	::1
cmrmj6ysz000bptdc8rwkweqq	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-15 20:27:06.803	Success	::1
cmrnu8nn70002yrdcg89o035r	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "testing" via GitHub	2026-07-16 18:24:07.603	Success	::1
cmrnuk13v0006e6dcp1ity5x0	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "testing" via GitHub	2026-07-16 18:32:58.267	Success	::1
cmrnv10i40000uydcrdsmobiu	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-16 18:46:10.636	Success	::1
cmrnv1mf50002uydca4omw8qx	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "testing" created	2026-07-16 18:46:39.041	Success	::1
cmrnv1mgi0003uydceqj99db6	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "testing" via ZIP	2026-07-16 18:46:39.09	Success	::1
cmrnv1pxk0006uydcilkmjii2	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "testing"	2026-07-16 18:46:43.592	Success	::1
cmqtswf1z0001h8dczv5zwls5	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test validasi" created	2026-06-25 17:53:31.703	Success	\N
cmqtvm18h0004ijdcg9tw0v60	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_DELETED	Container "test-port-1782414523105" deleted	2026-06-25 19:09:26.082	Success	\N
cmqwl3n6k0002t5dci8r2v4yk	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-27 16:38:30.428	Success	::1
cmqtw1bii0001epdc8aahhyb7	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_STARTED	Container "test-port-1782414595902" started	2026-06-25 19:21:19.242	Success	::1
cmqwohmx50001bkdcmo8ow9l9	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "test-port-1782414595902" restarted	2026-06-27 18:13:22.121	Success	::1
cmqwpkg450001xpdc6e7sjfzu	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_PORT_ALLOCATED	Allocated external port 19100 for container "test-port-1782414595902"	2026-06-27 18:43:32.886	Success	::1
cmqws3klg000jy7dcf1c13m3x	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-06-27 19:54:24.388	Success	::1
cmqwsz1ds00005jdc9egaay7e	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-static-nginx" via ZIP	2026-06-27 20:18:52.48	Success	::1
cmqwsz3s300025jdcruwbbhfr	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "test-static-nginx"	2026-06-27 20:18:55.587	Success	::1
cmqwt8z1y00013ldc6yobkk1k	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "static-apache-web" via ZIP	2026-06-27 20:26:36.022	Success	::1
cmqtqr0x00001hedc1up2g7pw	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "develop" created	2026-06-25 16:53:20.869	Success	\N
cmqtqr15m0002hedcvv1qutqv	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "develop" via ZIP	2026-06-25 16:53:21.178	Success	\N
cmqwqe7oa0002y7dc9zjvxisd	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_PORT_ALLOCATED	Allocated external port 19001 for container "develop-1782406408357"	2026-06-27 19:06:41.63	Success	::1
cmqwr8c8j0007y7dc1k390pfp	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESOURCES_UPDATED	Updated resources for container "develop-1782406408357" (RAM: 512MB, CPU: 0.5 Cores)	2026-06-27 19:30:07.219	Success	::1
cmqwtu1lb000cdjdcoebrbc2i	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-06-27 20:42:59.087	Success	::1
cmrac9zca0006sbdcz0juzrkc	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-07-07 07:40:16.042	Success	::1
cmqzesyh20000m2dcg3g1epqe	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-29 16:05:32.679	Success	::1
cmqzfguz30000w8dcmsoudw6j	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-29 16:24:07.887	Success	::1
cmrfzzxss00084kdcj0okunob	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "testing" created	2026-07-11 06:43:09.149	Success	::1
cmrfzzxu200094kdcos65tpg8	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "testing" via ZIP	2026-07-11 06:43:09.194	Success	::1
cmrg0wed1000g4kdcou04aigp	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_DELETED	Container "testing-1783752192129" deleted	2026-07-11 07:08:23.605	Success	::1
cmrg0whhu000h4kdcai1thja7	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_DELETED	Container "html-test-1783529862231" deleted	2026-07-11 07:08:27.666	Success	::1
cmqwu9dc70001fgdcyqulo447	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "php-apache-1782593440154" restarted	2026-06-27 20:54:54.151	Success	::1
cmrg0wl62000i4kdca7r4z7wt	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_DELETED	Container "php-apache-1782593440154" deleted	2026-07-11 07:08:32.426	Success	::1
cmqwuk7vc0006fgdclcqtxlti	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESOURCES_UPDATED	Updated resources for container "static-apache-1782592788280" (RAM: 512MB, CPU: 1 Cores)	2026-06-27 21:03:20.28	Success	::1
cmqwukbp70007fgdc6oh1i053	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESOURCES_UPDATED	Updated resources for container "static-apache-1782592788280" (RAM: 256MB, CPU: 1 Cores)	2026-06-27 21:03:25.243	Success	::1
cmrg1o6d5000p4kdc3mns7vje	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-11 07:29:59.609	Success	::1
cmqwto0zw0003djdclxgnecho	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "nginx-static" created	2026-06-27 20:38:18.38	Success	::1
cmqwto11q0004djdc54o7x5rw	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "nginx-static" via ZIP	2026-06-27 20:38:18.446	Success	::1
cmrg1o9l1000q4kdcwnvqbmk2	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-11 07:30:03.781	Success	::1
cmqzbtin00002x6dc9rp4vzvw	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_STOPPED	Container "testing-dockerfile-1782589290194" stopped	2026-06-29 14:41:59.964	Success	::1
cmqzbtn560003x6dcebjdmjzi	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_STARTED	Container "testing-dockerfile-1782589290194" started	2026-06-29 14:42:05.802	Success	::1
cmrg1od19000r4kdcv65231wb	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-11 07:30:08.253	Success	::1
cmrlsuju20000bqdcteyv3vo5	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in with 2FA	2026-07-15 08:09:37.514	Success	::1
cmrlv3ikw000973dc785jm97z	cmqtq4ojw00003odcvi7bopj5	\N	GENERATE_SSH_KEY	User generated a new SSH key	2026-07-15 09:12:35.024	Success	::1
cmrnuk1k30008e6dcz6pek7ta	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	GitHub deployment failed: Command failed: git clone --depth 1 --branch main https://github.com/azrilpramudia/TableTap-Restaurants-Management-System.git /home/meow/Documents/Project/portdock-caas/backend/uploads/cmrnu5onk0000yrdcrwt354ji/github-1784226778266\nCloning into '/home/meow/Documents/Project/portdock-caas/backend/uploads/cmrnu5onk0000yrdcrwt354ji/github-1784226778266'...\nfatal: could not read Username for 'https://github.com': terminal prompts disabled\n	2026-07-16 18:32:58.851	Failed	::1
cmrnubmvo0000e6dcawpc71vb	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "testing" via GitHub	2026-07-16 18:26:26.58	Success	::1
cmrmirp900006b3dcwvgfs2js	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test" created	2026-07-15 20:15:14.58	Success	::1
cmrmirpaq0007b3dcejvugcm9	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test" via ZIP	2026-07-15 20:15:14.642	Success	::1
cmrmirsnw000ab3dcfehe7uf5	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "test"	2026-07-15 20:15:19.004	Success	::1
cmroyoocy0000r1dco2hmfue3	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-07-17 13:16:19.667	Success	::1
cmrozpmco00049zdcom50xo20	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-07-17 13:45:03.336	Success	::1
cmqtsx4mo0002h8dcc6o050rq	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-06-25 17:54:04.848	Success	\N
cmqtvm5t30005ijdcuz000if6	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-06-25 19:09:32.007	Success	\N
cmqwm0edv0003t5dcj7wcew8b	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-27 17:03:58.675	Success	::1
cmqwomagy00001ndc345mh38v	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "test-port-1782414595902" restarted	2026-06-27 18:16:59.267	Success	::1
cmqwpklgq0002xpdckasr4hod	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "test-port-1782414595902" restarted	2026-06-27 18:43:39.818	Success	::1
cmqwsk1zy000ly7dcrnpy9r4x	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test-static-nginx" created	2026-06-27 20:07:13.438	Success	::1
cmqwsk216000my7dc9vya2yjw	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-static-nginx" via ZIP	2026-06-27 20:07:13.482	Success	::1
cmqwsk4ut000oy7dcjenbgrsl	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "test-static-nginx"	2026-06-27 20:07:17.141	Success	::1
cmqwszlz400035jdcu1wc83ms	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-06-27 20:19:19.168	Success	::1
cmqwt9g2700033ldcofpyfj9k	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "static-apache-web"	2026-06-27 20:26:58.063	Success	::1
cmqtqr6pn0004hedckyzvbhhy	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "develop"	2026-06-25 16:53:28.379	Success	\N
cmqwqhtc80003y7dc5lknv2xl	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "develop-1782406408357" restarted	2026-06-27 19:09:29.672	Success	::1
cmqwr8ep30008y7dcl2skh9uf	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "develop-1782406408357" restarted	2026-06-27 19:30:10.407	Success	::1
cmqzd0aea00054zdcv25kpk9p	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test-code" created	2026-06-29 15:15:15.49	Success	::1
cmqzd0agn00064zdcbku66z5w	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-code" via ZIP	2026-06-29 15:15:15.575	Success	::1
cmqzd0b4v00084zdcdsg98tg3	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "test-code"	2026-06-29 15:15:16.447	Success	::1
cmqzeubl30001m2dckqjst5op	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-29 16:06:36.327	Success	::1
cmqzflire0001w8dcpo33lded	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-06-29 16:27:45.338	Success	::1
cmrg00042000c4kdcxsxt6kyw	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "testing"	2026-07-11 06:43:12.148	Success	::1
cmqwu2ta9000edjdchlqgycbx	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "php-apache" created	2026-06-27 20:49:48.225	Success	::1
cmqwu2tbf000fdjdctinngcfi	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "php-apache" via ZIP	2026-06-27 20:49:48.267	Success	::1
cmqwujs580002fgdc2pfygz7t	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESOURCES_UPDATED	Updated resources for container "static-apache-1782592788280" (RAM: 256MB, CPU: 0.5 Cores)	2026-06-27 21:02:59.9	Success	::1
cmqwujytt0004fgdczy6ol4wv	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESOURCES_UPDATED	Updated resources for container "static-apache-1782592788280" (RAM: 256MB, CPU: 1 Cores)	2026-06-27 21:03:08.561	Success	::1
cmqwuk47e0005fgdcucmri00q	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "static-apache-1782592788280" restarted	2026-06-27 21:03:15.53	Success	::1
cmqwukf060008fgdcsvk0hcvw	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "static-apache-1782592788280" restarted	2026-06-27 21:03:29.526	Success	::1
cmrg0wp99000j4kdc8bw854v5	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_DELETED	Container "static-apache-1782592788280" deleted	2026-07-11 07:08:37.725	Success	::1
cmqwtokx90006djdcxedpljuf	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "nginx-static"	2026-06-27 20:38:44.205	Success	::1
cmrg0wsij000k4kdcmaxkjbqj	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_DELETED	Container "nginx-static-1782592724176" deleted	2026-07-11 07:08:41.947	Success	::1
cmrg0wvl3000l4kdcvo6h1qjt	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_DELETED	Container "testing-dockerfile-1782589290194" deleted	2026-07-11 07:08:45.927	Success	::1
cmrkcdlao0000hzdch7oldi40	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in	2026-07-14 07:40:46.225	Success	::1
cmrlsoaec0000cedcilc8zw8v	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in with 2FA	2026-07-15 08:04:45.348	Success	::1
cmrlt0d810001bqdcsqh2of8q	cmqtq4ojw00003odcvi7bopj5	\N	LOGIN	User logged in with 2FA	2026-07-15 08:14:08.881	Success	::1
cmrlv3luq000a73dcyvpcn5y6	cmqtq4ojw00003odcvi7bopj5	\N	GENERATE_SSH_KEY	User generated a new SSH key	2026-07-15 09:12:39.266	Success	::1
cmrme66g40000hndcauzwxs0i	cmqzg0qll0002w8dcorklsynq	\N	LOGIN	User logged in	2026-07-15 18:06:31.972	Success	::1
cmrmj69h20007ptdc6qj0deqi	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test-notif" created	2026-07-15 20:26:33.974	Success	::1
cmrmj69ix0008ptdc9u86v4wv	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-notif" via Custom Dockerfile	2026-07-15 20:26:34.041	Success	::1
cmrmj69k1000aptdcssittw5f	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	Custom Dockerfile deployment failed: (HTTP code 400) unexpected - dockerfile parse error on line 1: unknown instruction: PK 	2026-07-15 20:26:34.081	Success	::1
cmrnubnem0002e6dc8q3i7yp5	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	GitHub deployment failed: Command failed: git clone --depth 1 --branch main https://github.com/azrilpramudia/TableTap-Restaurants-Management-System.git /home/meow/Documents/Project/portdock-caas/backend/uploads/cmrnu5onk0000yrdcrwt354ji/github-1784226386569\nCloning into '/home/meow/Documents/Project/portdock-caas/backend/uploads/cmrnu5onk0000yrdcrwt354ji/github-1784226386569'...\nfatal: could not read Username for 'https://github.com': terminal prompts disabled\n	2026-07-16 18:26:27.262	Failed	::1
cmrnu5oo00001yrdcdcts4i8t	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "testing" created	2026-07-16 18:21:48.96	Success	::1
cmrnuexsh0003e6dc5y7jcbax	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "testing" via GitHub	2026-07-16 18:29:00.689	Success	::1
cmrnuey890005e6dcd9kp0t3j	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	GitHub deployment failed: Command failed: git clone --depth 1 --branch main https://github.com/azrilpramudia/TableTap-Restaurants-Management-System.git /home/meow/Documents/Project/portdock-caas/backend/uploads/cmrnu5onk0000yrdcrwt354ji/github-1784226540688\nCloning into '/home/meow/Documents/Project/portdock-caas/backend/uploads/cmrnu5onk0000yrdcrwt354ji/github-1784226540688'...\nfatal: could not read Username for 'https://github.com': terminal prompts disabled\n	2026-07-16 18:29:01.258	Failed	::1
cmrnuksv20009e6dcriq6afr9	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-16 18:33:34.238	Success	::1
cmro12vey0000k1dcrqajz7jv	cmqtq4ojw00003odcvi7bopj5	\N	Start Database	Started managed database: test-db	2026-07-16 21:35:35.05	Success	\N
cmro19865000065dclo67h6e5	cmqtq4ojw00003odcvi7bopj5	\N	Restart Database	Restarted managed database: test-db	2026-07-16 21:40:31.517	Success	::1
cmrnw4gwl0001owdclc0tovec	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "frontend" created	2026-07-16 19:16:51.477	Success	::1
cmrnw4gyc0002owdcmone72ln	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "frontend" via ZIP	2026-07-16 19:16:51.54	Success	::1
cmrnw4hr00005owdc9sd17fnz	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "frontend"	2026-07-16 19:16:52.572	Success	::1
cmro0agol0004j5dcx4i20je9	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_UPDATED	Project "frontend" updated	2026-07-16 21:13:29.589	Success	::1
cmrpvyw2b000c9cdcv7m1v1bn	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 04:48:03.539	Success	::1
cmrpv21xw0001l2dcf5bl21im	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test-prod" created	2026-07-18 04:22:31.508	Success	::1
cmrpv21zx0002l2dc0go3ss52	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-prod" via Custom Dockerfile	2026-07-18 04:22:31.581	Success	::1
cmrpv24we0005l2dc8puathhp	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Custom Dockerfile deployment completed successfully for "test-prod"	2026-07-18 04:22:35.342	Success	::1
cmrpvz09b000d9cdc6mawvgrn	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 04:48:08.975	Success	::1
cmrpwd04l000l9cdcy6wy6d07	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "himatif-uninus" created	2026-07-18 04:59:01.989	Success	::1
cmrpwd059000m9cdc4nxhk9rd	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "himatif-uninus" via GitHub	2026-07-18 04:59:02.013	Success	::1
cmrpwf5kn000p9cdce6zw65yo	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	GitHub deployment failed: Nixpacks build failed with exit code 1	2026-07-18 05:00:42.359	Failed	::1
cmrpwfhvd000022dctjyu9nv0	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 05:00:58.297	Success	::1
cmrpy9umj0006phdctble8hzy	cmqtq4ojw00003odcvi7bopj5	\N	Create Database	Provisioned managed database: my-db	2026-07-18 05:52:34.123	Success	::1
cmrpya6090008phdckblc5phm	cmqtq4ojw00003odcvi7bopj5	\N	Create Database	Provisioned managed database: my-db	2026-07-18 05:52:48.873	Success	::1
cmrpyai8u0009phdclh63pimn	cmqtq4ojw00003odcvi7bopj5	\N	Delete Database	Deleted managed database: my-db	2026-07-18 05:53:04.734	Success	::1
cmrpz4jbf000bphdcwyc35slm	cmqtq4ojw00003odcvi7bopj5	\N	Restart Database	Restarted managed database: test-db	2026-07-18 06:16:25.804	Success	::1
cmrnwhidz0000r5dc5m3c2ive	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_PORT_ALLOCATED	Allocated external port 19501 for container "testing-1784227603550"	2026-07-16 19:26:59.928	Success	::1
cmrnwhlds0001r5dc1bpthnen	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "testing-1784227603550" restarted	2026-07-16 19:27:03.808	Success	::1
cmrpvqjd900019cdczu97mqv0	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "ssl-test" created	2026-07-18 04:41:33.837	Success	::1
cmrpvqjeh00029cdc4dc9rfyb	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "ssl-test" via Custom Dockerfile	2026-07-18 04:41:33.881	Success	::1
cmrpwgizd000222dctkbm1ril	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "personal" created	2026-07-18 05:01:46.393	Success	::1
cmrpwgj0r000322dcliupvmnw	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "personal" via GitHub	2026-07-18 05:01:46.443	Success	::1
cmrpwizh4000522dcl1p44f3s	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	GitHub deployment failed: Nixpacks build failed with exit code 1	2026-07-18 05:03:41.08	Failed	::1
cmrpwslo000006jdcrvootoja	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "personal" via GitHub	2026-07-18 05:11:09.744	Success	::1
cmrpwuqg700026jdchvvu70vt	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	GitHub deployment failed: Nixpacks build failed with exit code 1	2026-07-18 05:12:49.255	Failed	::1
cmrpx0mwc0000phdc9dgekxnv	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "personal" via GitHub	2026-07-18 05:17:24.588	Success	::1
cmrpxaquj0003phdca55t8xjm	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	GitHub deployment succeeded for "personal"	2026-07-18 05:25:16.268	Success	::1
cmrpxie3n0004phdc9oa0x4ca	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_UPDATED	Project "personal" updated	2026-07-18 05:31:12.995	Success	::1
cmrpvzgbj000f9cdcbbnx7viu	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "testing-ssl" created	2026-07-18 04:48:29.791	Success	::1
cmrpvzgd7000g9cdc7sxtm9em	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "testing-ssl" via Custom Dockerfile	2026-07-18 04:48:29.851	Success	::1
cmrpvzh2x000j9cdcxnj5dzdt	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Custom Dockerfile deployment completed successfully for "testing-ssl"	2026-07-18 04:48:30.777	Success	::1
cmrpz901q000cphdcklr6d90h	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_UPDATED	Project "testing-ssl" updated	2026-07-18 06:19:54.11	Success	::1
cmrpzx5d2000dphdcunodj84u	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 06:38:40.742	Success	::1
cmrpvqk3x00049cdcrdg2jjne	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	Custom Dockerfile deployment failed: (HTTP code 500) server error - failed to set up container networking: driver failed programming external connectivity on endpoint ssl-test-1784349694104 (406f77001d69140a18308fd612490ea201ef032c8e96ae36a05f7bb428827064): Bind for 0.0.0.0:8003 failed: port is already allocated 	2026-07-18 04:41:34.798	Failed	::1
cmrpvrmdf00059cdcoee1qyhd	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "ssl-test" via ZIP	2026-07-18 04:42:24.387	Success	::1
cmrpvroar00079cdc4dniyo1f	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	Deployment failed: (HTTP code 500) server error - failed to set up container networking: driver failed programming external connectivity on endpoint ssl-test-1784349745997 (48c514140883b42ae3a2336c2af1b53c29206f0fd8a6e76ba6635abfe1eed956): Bind for 0.0.0.0:8003 failed: port is already allocated 	2026-07-18 04:42:26.883	Failed	::1
cmrpvtwjc00089cdc77qxkwet	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "ssl-test" via ZIP	2026-07-18 04:44:10.872	Success	::1
cmrpvwyi0000b9cdc98p7sky0	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "ssl-test"	2026-07-18 04:46:33.384	Success	::1
cmrqn419c00009gdcmduvvv17	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 17:27:53.186	Success	::1
cmrqn4tfv00019gdcrq4jgs11	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 17:28:29.707	Success	::1
cmrpzxvc0000ephdckpaw6ahf	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_PORT_ALLOCATED	Allocated external port 21000 for container "testing-ssl-1784350110763"	2026-07-18 06:39:14.4	Success	::1
cmrpzxyrh000fphdclcpe1j2p	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "testing-ssl-1784350110763" restarted	2026-07-18 06:39:18.845	Success	::1
cmrpzz2xn000gphdc1eted4pe	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "testing-ssl-1784350110763" restarted	2026-07-18 06:40:10.907	Success	::1
cmrq2a64r000iphdcppjza4v1	cmqtq4ojw00003odcvi7bopj5	\N	CONTAINER_RESTARTED	Container "testing-ssl-1784350110763" restarted	2026-07-18 07:44:47.499	Success	::1
cmrqn4xgb00029gdc3oegisuy	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 17:28:34.907	Success	::1
cmrqn5zm400049gdcq4789n5j	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "ikmal-test" created	2026-07-18 17:29:24.364	Success	::1
cmrqn5zox00059gdc3zmrv686	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "ikmal-test" via ZIP	2026-07-18 17:29:24.465	Success	::1
cmrqn60hu00089gdc85blnj68	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "ikmal-test"	2026-07-18 17:29:25.506	Success	::1
cmrqn6bss00099gdc5geg8iw7	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 17:29:40.156	Success	::1
cmrqn6rv2000b9gdc09ah7vy4	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "test-local" created	2026-07-18 17:30:00.974	Success	::1
cmrqn6rwh000c9gdccl3rqkbf	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "test-local" via Custom Dockerfile	2026-07-18 17:30:01.025	Success	::1
cmrqn6wwr000e9gdc97gqjgf0	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	Custom Dockerfile deployment failed: COPY failed: file not found in build context or excluded by .dockerignore: stat index.html: file does not exist	2026-07-18 17:30:07.515	Failed	::1
cmrqn9xnt000f9gdcj2k96bxx	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 17:32:28.457	Success	::1
cmrqna8aj000h9gdcwgcm2ti4	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "hello" created	2026-07-18 17:32:42.235	Success	::1
cmrqna8bc000i9gdczzlce34b	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "hello" via Custom Dockerfile	2026-07-18 17:32:42.264	Success	::1
cmrqna8fb000k9gdc4ot7ddy1	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_FAILED	Custom Dockerfile deployment failed: COPY failed: file not found in build context or excluded by .dockerignore: stat index.html: file does not exist	2026-07-18 17:32:42.407	Failed	::1
cmrqnfcjx000r9gdcqw7zv9zv	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 17:36:41.038	Success	::1
cmrqoer6i0001o2dc8xuuh3h7	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "php-apache" created	2026-07-18 18:04:12.954	Success	::1
cmrqnfprb000t9gdcci5m1sst	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "nginx-static" created	2026-07-18 17:36:58.151	Success	::1
cmrqnfps8000u9gdcx0pzirmr	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "nginx-static" via ZIP	2026-07-18 17:36:58.184	Success	::1
cmrqnftfd000x9gdcet8n9q6y	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "nginx-static"	2026-07-18 17:37:02.905	Success	::1
cmrqnew98000m9gdc1hsl7n3n	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "nixpacks" created	2026-07-18 17:36:19.916	Success	::1
cmrqnew9z000n9gdcjen0z9uc	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "nixpacks" via ZIP	2026-07-18 17:36:19.943	Success	::1
cmrqnf4wz000q9gdcsfnzuodt	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "nixpacks"	2026-07-18 17:36:31.139	Success	::1
cmrq341jp000289dcsg6okf0z	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "ikmal-test" created	2026-07-18 08:08:01.237	Success	::1
cmrq341nr000389dctvntpq3g	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "ikmal-test" via ZIP	2026-07-18 08:08:01.383	Success	::1
cmrq34bwx000689dc4qh5qvwc	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "ikmal-test"	2026-07-18 08:08:14.673	Success	::1
cmrqnrp8s000y9gdcj3fiyfy0	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "ikmal-test" via ZIP	2026-07-18 17:46:17.356	Success	::1
cmrqog6zj0007o2dczl83304z	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "apache-static" created	2026-07-18 18:05:20.095	Success	::1
cmrqog70j0008o2dcs9zzla9q	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "apache-static" via ZIP	2026-07-18 18:05:20.131	Success	::1
cmrqog8ym000bo2dcnevuqwoy	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "apache-static"	2026-07-18 18:05:22.654	Success	::1
cmrqogzzx000co2dc40c1t54c	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "apache-static" via ZIP	2026-07-18 18:05:57.693	Success	::1
cmrqoh237000fo2dcicokh3bk	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "apache-static"	2026-07-18 18:06:00.403	Success	::1
cmrqohila000go2dcg5616i0h	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 18:06:21.79	Success	::1
cmrqoer8f0002o2dcf5ff4bu0	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "php-apache" via ZIP	2026-07-18 18:04:13.023	Success	::1
cmrqoerv20005o2dcw440qzgi	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "php-apache"	2026-07-18 18:04:13.838	Success	::1
cmrqovgnb00002tdc4dwj0iv6	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 18:17:12.456	Success	::1
cmrqow9ta00022tdchdfpo38m	cmqtq4ojw00003odcvi7bopj5	cmrqow9sy00012tdcvvle3az4	PROJECT_CREATED	Project "ucok-web" created	2026-07-18 18:17:50.254	Success	::1
cmrqow9v100032tdcmmpeex8c	cmqtq4ojw00003odcvi7bopj5	cmrqow9sy00012tdcvvle3az4	DEPLOYMENT_STARTED	Deployment started for "ucok-web" via ZIP	2026-07-18 18:17:50.317	Success	::1
cmrqowahj00062tdc2n2w8duk	cmqtq4ojw00003odcvi7bopj5	cmrqow9sy00012tdcvvle3az4	DEPLOYMENT_SUCCESS	Deployment succeeded for "ucok-web"	2026-07-18 18:17:51.127	Success	::1
cmrqp48j90000i9dcl3fcxfg5	cmqtq4ojw00003odcvi7bopj5	cmrqow9sy00012tdcvvle3az4	PROJECT_UPDATED	Project "ucok-web" updated	2026-07-18 18:24:01.845	Success	::1
cmrqohtgh000io2dc4q8x8y60	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_CREATED	Project "apache-static" created	2026-07-18 18:06:35.873	Success	::1
cmrqohthk000jo2dc7chwkajv	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "apache-static" via ZIP	2026-07-18 18:06:35.912	Success	::1
cmrqohvet000mo2dc62mmrhag	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "apache-static"	2026-07-18 18:06:38.405	Success	::1
cmrqp6khu0001i9dck2aww42j	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 18:25:50.658	Success	::1
cmrqp6oat0002i9dck0duw58u	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 18:25:55.589	Success	::1
cmrqp6s7j0003i9dcn95zl3cx	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 18:26:00.655	Success	::1
cmrqnrqe200119gdcsnow02rt	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "ikmal-test"	2026-07-18 17:46:18.842	Success	::1
cmrqo6ci40000u4dchbo6o515	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_STARTED	Deployment started for "ikmal-test" via ZIP	2026-07-18 17:57:40.684	Success	::1
cmrqo6dgj0003u4dc8he7d08e	cmqtq4ojw00003odcvi7bopj5	\N	DEPLOYMENT_SUCCESS	Deployment succeeded for "ikmal-test"	2026-07-18 17:57:41.923	Success	::1
cmrqp6ws00004i9dcv4rfdpbl	cmqtq4ojw00003odcvi7bopj5	\N	PROJECT_DELETED	Project deleted	2026-07-18 18:26:06.576	Success	::1
cmrqp7gsd0006i9dcx59m9sor	cmqtq4ojw00003odcvi7bopj5	cmrqp7gs40005i9dclxxm1usp	PROJECT_CREATED	Project "burhan-snake" created	2026-07-18 18:26:32.509	Success	::1
cmrqp7gtw0007i9dc9rw4vne3	cmqtq4ojw00003odcvi7bopj5	cmrqp7gs40005i9dclxxm1usp	DEPLOYMENT_STARTED	Deployment started for "burhan-snake" via ZIP	2026-07-18 18:26:32.564	Success	::1
cmrqp7hdl000ai9dc8ajh4uns	cmqtq4ojw00003odcvi7bopj5	cmrqp7gs40005i9dclxxm1usp	DEPLOYMENT_SUCCESS	Deployment succeeded for "burhan-snake"	2026-07-18 18:26:33.273	Success	::1
cmrqpgm810000nedcd8j7d4w2	cmqtq4ojw00003odcvi7bopj5	cmrqp7gs40005i9dclxxm1usp	DEPLOYMENT_STARTED	Deployment started for "burhan-snake" via ZIP	2026-07-18 18:33:39.457	Success	::1
cmrqpgn5r0003nedckgn0f8xn	cmqtq4ojw00003odcvi7bopj5	cmrqp7gs40005i9dclxxm1usp	DEPLOYMENT_SUCCESS	Deployment succeeded for "burhan-snake"	2026-07-18 18:33:40.673	Success	::1
cmrqppvk10000i6dconkrmhwj	cmqtq4ojw00003odcvi7bopj5	cmrqow9sy00012tdcvvle3az4	DEPLOYMENT_STARTED	Deployment started for "ucok-web" via ZIP	2026-07-18 18:40:51.457	Success	::1
cmrqppwex0003i6dcl53bzy4l	cmqtq4ojw00003odcvi7bopj5	cmrqow9sy00012tdcvvle3az4	DEPLOYMENT_SUCCESS	Deployment succeeded for "ucok-web"	2026-07-18 18:40:52.569	Success	::1
cmrqptm420004i6dcs8scy2wy	cmqtq4ojw00003odcvi7bopj5	cmrqp7gs40005i9dclxxm1usp	PROJECT_UPDATED	Project "burhan-snake" updated	2026-07-18 18:43:45.842	Success	::1
cmrqq0nmu00006jdcny0ueutk	cmqtq4ojw00003odcvi7bopj5	cmrqp7gs40005i9dclxxm1usp	PROJECT_UPDATED	Project "burhan-snake" updated	2026-07-18 18:49:14.407	Success	::1
cmrqq11mq00016jdc62zwl7xv	cmqtq4ojw00003odcvi7bopj5	cmrqp7gs40005i9dclxxm1usp	PROJECT_UPDATED	Project "burhan-snake" updated	2026-07-18 18:49:32.546	Success	::1
\.


--
-- Data for Name: containers; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.containers (id, project_id, docker_container_id, name, image_name, image_tag, subdomain, internal_port, host_port, status, created_at, updated_at, cpu_limit, memory_limit, restart_policy, volume_mount_path) FROM stdin;
cmrac8b2i0004sbdct1dfd287	cmrac8ac20001sbdcjtm15ofh	8d6ae5dc4195b5b7609c8fe6d71b6ca6ca5379793c82753a352b85c006a0fe93	html-1783409937916	portdock-cmrac8ac20001sbdcjtm15ofh	v1783409937077	\N	80	8000	RUNNING	2026-07-07 07:38:57.93	2026-07-07 07:38:57.93	1	512	unless-stopped	\N
cmrqpgmta0002nedcmevk1uv7	cmrqp7gs40005i9dclxxm1usp	946a87fd80f571e860720a62cac622d8928c57eecafed147bfd91c9542620422	burhan-snake-1784399620216	portdock-cmrqp7gs40005i9dclxxm1usp	v1784399619496	\N	80	8002	RUNNING	2026-07-18 18:33:40.222	2026-07-18 18:33:40.222	1	512	unless-stopped	\N
cmrqppw3o0002i6dccfo479ka	cmrqow9sy00012tdcvvle3az4	e37a9f5517c3fdf511d63297d0f62f4361726cd8dc5821cb1985b7c524cf1986	ucok-web-1784400052159	portdock-cmrqow9sy00012tdcvvle3az4	v1784400051505	\N	80	8001	RUNNING	2026-07-18 18:40:52.164	2026-07-18 18:40:52.164	1	512	unless-stopped	\N
\.


--
-- Data for Name: deployments; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.deployments (id, project_id, status, progress, started_at, ended_at, domain, commit_hash) FROM stdin;
cmrqow9vf00042tdct18e34r9	cmrqow9sy00012tdcvvle3az4	Success	100	2026-07-18 18:17:50.331	2026-07-18 18:17:51.131	ucok.com	\N
cmrqp7gu70008i9dcbs7tpk4p	cmrqp7gs40005i9dclxxm1usp	Success	100	2026-07-18 18:26:32.575	2026-07-18 18:26:33.278	burhan-snake.portdock.my.id	\N
cmrqpgm8f0001nedcwi4rix2h	cmrqp7gs40005i9dclxxm1usp	Success	100	2026-07-18 18:33:39.471	2026-07-18 18:33:40.679	burhan-snake.portdock.my.id	\N
cmrqppvkq0001i6dcdhfdzba4	cmrqow9sy00012tdcvvle3az4	Success	100	2026-07-18 18:40:51.482	2026-07-18 18:40:52.571	ucok-sementara.com	\N
\.


--
-- Data for Name: managed_databases; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.managed_databases (id, user_id, name, type, version, db_user, db_password, db_name, docker_container_id, internal_port, host_port, status, memory_limit, cpu_limit, volume_name, created_at, updated_at) FROM stdin;
cmrpy9u320005phdcz9jod2sw	cmqtq4ojw00003odcvi7bopj5	my-db	POSTGRESQL	15-alpine	portdock	daf0e34e333c3f9d	my_db	2bec425222303d32ad5197f82300072f0b2686150fff1c718dd93819c446abc8	5432	40001	RUNNING	512	0.5	portdock-dbvol-cmrpy9u320005phdcz9jod2sw	2026-07-18 05:52:33.422	2026-07-18 05:52:34.119
cmro0m37q0000l1dc4kart1av	cmqtq4ojw00003odcvi7bopj5	test-db	MYSQL	8.0	portdock	6ea480b6109aecd0	test_db	5146722b99bc02d313b7e999cbc8eb5481234e112d932dca315f1dcc4715a3a6	3306	40000	RUNNING	512	0.5	portdock-dbvol-cmro0m37q0000l1dc4kart1av	2026-07-16 21:22:32.007	2026-07-18 06:16:25.813
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.projects (id, user_id, name, description, deployment_type, repository_url, domain, status, created_at, updated_at, env_vars, template_id, branch, build_command, start_command, domain_expires_at, ssl_expires_at) FROM stdin;
cmrqow9sy00012tdcvvle3az4	cmqtq4ojw00003odcvi7bopj5	ucok-web	website ucok	ZIP	\N	ucok-sementara.com	ACTIVE	2026-07-18 18:17:50.242	2026-07-18 18:40:52.562	{}	STATIC_NGINX	\N	\N	\N	\N	\N
cmrqp7gs40005i9dclxxm1usp	cmqtq4ojw00003odcvi7bopj5	burhan-snake		ZIP	\N	burhan-snake.id	ACTIVE	2026-07-18 18:26:32.5	2026-07-18 18:49:32.54	{}	STATIC_NGINX	\N	\N	\N	\N	\N
cmrac8ac20001sbdcjtm15ofh	cmqzg0qll0002w8dcorklsynq	html	\N	ZIP	\N	test-html.portdock.my.id	ACTIVE	2026-07-07 07:38:56.978	2026-07-11 19:40:15.901	\N	STATIC_NGINX	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.sessions (id, user_id, ip_address, user_agent, last_active, expires_at, created_at) FROM stdin;
cmrme66hp0001hndc70qcbxfl	cmqzg0qll0002w8dcorklsynq	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-07-15 18:07:02.889	2026-07-22 18:06:32.027	2026-07-15 18:06:32.03
cmroyoodg0001r1dcifjcncxk	cmqtq4ojw00003odcvi7bopj5	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-07-17 13:44:52.45	2026-07-24 13:16:19.682	2026-07-17 13:16:19.684
cmrozpmcy00059zdc1z5tk1qs	cmqtq4ojw00003odcvi7bopj5	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-07-18 18:59:56.245	2026-07-24 13:45:03.343	2026-07-17 13:45:03.347
\.


--
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.system_metrics (id, cpu, ram, disk, "networkOut", created_at) FROM stdin;
cmrd937xw0000undcxyukwwjj	64	8	45	1.5	2026-07-02 08:34:20.048
cmrd937xw0001undcna0rskya	80	8	45	1.5	2026-07-02 10:34:20.048
cmrd937xw0002undcm53z8m4d	64	9	45	1.5	2026-07-02 12:34:20.048
cmrd937xw0003undci3qwjlp8	63	12	45	1.5	2026-07-02 14:34:20.048
cmrd937xw0004undc9wxo17qv	69	8	45	1.5	2026-07-02 16:34:20.048
cmrd937xw0005undcxz7mxuu9	48	8	45	1.5	2026-07-02 18:34:20.048
cmrd937xw0006undcrpmqxx68	77	10	45	1.5	2026-07-02 20:34:20.048
cmrd937xw0007undcs0l3r463	78	8	45	1.5	2026-07-02 22:34:20.048
cmrd937xw0008undcq6u6vu9e	39	11	45	1.5	2026-07-03 00:34:20.048
cmrd937xw0009undcbo19wn80	45	11	45	1.5	2026-07-03 02:34:20.048
cmrd937xw000aundc57jujhjs	82	7	45	1.5	2026-07-03 04:34:20.048
cmrd937xw000bundc7dys1n07	74	8	45	1.5	2026-07-03 06:34:20.048
cmrd937xw000cundc6hs49vlx	57	12	45	1.5	2026-07-03 08:34:20.048
cmrd937xx000dundcf41uhwtd	47	12	45	1.5	2026-07-03 10:34:20.048
cmrd937xx000eundco4kjjq1s	76	8	45	1.5	2026-07-03 12:34:20.048
cmrd937xx000fundc4d1pwe2m	43	6	45	1.5	2026-07-03 14:34:20.048
cmrd937xx000gundcxhqw5p98	83	12	45	1.5	2026-07-03 16:34:20.048
cmrd937xx000hundcqks4y2cf	41	12	45	1.5	2026-07-03 18:34:20.048
cmrd937xx000iundcsxdtwj3j	30	9	45	1.5	2026-07-03 20:34:20.048
cmrd937xx000jundcdba05s7v	74	9	45	1.5	2026-07-03 22:34:20.048
cmrd937xx000kundc3ekhskp0	69	6	45	1.5	2026-07-04 00:34:20.048
cmrd937xx000lundc3eghgr19	85	7	45	1.5	2026-07-04 02:34:20.048
cmrd937xx000mundcpc1u6w7b	37	6	45	1.5	2026-07-04 04:34:20.048
cmrd937xx000nundcrgy354dw	42	11	45	1.5	2026-07-04 06:34:20.048
cmrd937xx000oundckiv4pneb	33	10	45	1.5	2026-07-04 08:34:20.048
cmrd937xx000pundcasm8777v	68	6	45	1.5	2026-07-04 10:34:20.048
cmrd937xx000qundcif92ymf2	53	7	45	1.5	2026-07-04 12:34:20.048
cmrd937xx000rundc258makcl	50	12	45	1.5	2026-07-04 14:34:20.048
cmrd937xx000sundcmgj26m4y	53	6	45	1.5	2026-07-04 16:34:20.048
cmrd937xx000tundc13daiogd	81	10	45	1.5	2026-07-04 18:34:20.048
cmrd937xx000uundc12dwguvq	37	12	45	1.5	2026-07-04 20:34:20.048
cmrd937xx000vundcwbcok70c	34	8	45	1.5	2026-07-04 22:34:20.048
cmrd937xx000wundc2zkm6sdh	33	7	45	1.5	2026-07-05 00:34:20.048
cmrd937xx000xundcxmavnq8j	73	8	45	1.5	2026-07-05 02:34:20.048
cmrd937xx000yundcqh743az3	68	11	45	1.5	2026-07-05 04:34:20.048
cmrd937xx000zundcgeqy3u2z	59	10	45	1.5	2026-07-05 06:34:20.048
cmrd937xx0010undc2voc7cvi	73	11	45	1.5	2026-07-05 08:34:20.048
cmrd937xx0011undck58g8n6y	56	8	45	1.5	2026-07-05 10:34:20.048
cmrd937xx0012undccaa23sjj	51	6	45	1.5	2026-07-05 12:34:20.048
cmrd937xx0013undco28ko9yx	70	6	45	1.5	2026-07-05 14:34:20.048
cmrd937xx0014undcbge5o97r	60	12	45	1.5	2026-07-05 16:34:20.048
cmrd937xx0015undchs00pn3i	84	10	45	1.5	2026-07-05 18:34:20.048
cmrd937xx0016undcom6ofdp8	42	11	45	1.5	2026-07-05 20:34:20.048
cmrd937xx0017undch7xhimxy	55	9	45	1.5	2026-07-05 22:34:20.048
cmrd937xx0018undc5nvjlbjw	56	10	45	1.5	2026-07-06 00:34:20.048
cmrd937xx0019undcjc0le6sd	53	11	45	1.5	2026-07-06 02:34:20.048
cmrd937xx001aundccwaqzjzj	74	11	45	1.5	2026-07-06 04:34:20.048
cmrd937xx001bundcjbdo4f4l	30	10	45	1.5	2026-07-06 06:34:20.048
cmrd937xx001cundc9m53w0mx	35	8	45	1.5	2026-07-06 08:34:20.048
cmrd937xx001dundcmddxh044	43	8	45	1.5	2026-07-06 10:34:20.048
cmrd937xx001eundckors5aby	74	10	45	1.5	2026-07-06 12:34:20.048
cmrd937xx001fundci1lmo76h	53	9	45	1.5	2026-07-06 14:34:20.048
cmrd937xx001gundc41igfoe5	55	6	45	1.5	2026-07-06 16:34:20.048
cmrd937xx001hundco2zl6rot	73	9	45	1.5	2026-07-06 18:34:20.048
cmrd937xx001iundca3vkwzqa	37	8	45	1.5	2026-07-06 20:34:20.048
cmrd937xx001jundc25ue5ktf	30	9	45	1.5	2026-07-06 22:34:20.048
cmrd937xx001kundce1uzo93h	84	10	45	1.5	2026-07-07 00:34:20.048
cmrd937xx001lundc1v87ytc9	75	10	45	1.5	2026-07-07 02:34:20.048
cmrd937xx001mundclznx7gnr	52	9	45	1.5	2026-07-07 04:34:20.048
cmrd937xx001nundckxabsisr	41	6	45	1.5	2026-07-07 06:34:20.048
cmrd937xx001oundccvc6nxq2	68	6	45	1.5	2026-07-07 08:34:20.048
cmrd937xx001pundc131ehnn8	53	6	45	1.5	2026-07-07 10:34:20.048
cmrd937xx001qundcml3psbmc	54	12	45	1.5	2026-07-07 12:34:20.048
cmrd937xx001rundc9cxldbwf	66	7	45	1.5	2026-07-07 14:34:20.048
cmrd937xx001sundc0amcwl2w	78	8	45	1.5	2026-07-07 16:34:20.048
cmrd937xx001tundc7zxs32g2	41	9	45	1.5	2026-07-07 18:34:20.048
cmrd937xx001uundcld2i8dbe	37	8	45	1.5	2026-07-07 20:34:20.048
cmrd937xx001vundchuepz0af	61	8	45	1.5	2026-07-07 22:34:20.048
cmrd937xx001wundc899txyw9	84	9	45	1.5	2026-07-08 00:34:20.048
cmrd937xx001xundczk389wm3	39	10	45	1.5	2026-07-08 02:34:20.048
cmrd937xx001yundcrilifsdo	79	7	45	1.5	2026-07-08 04:34:20.048
cmrd937xx001zundcmqmxgbwr	55	9	45	1.5	2026-07-08 06:34:20.048
cmrd937xx0020undcmkmze7yo	76	6	45	1.5	2026-07-08 08:34:20.048
cmrd937xx0021undcc2t8zju3	32	12	45	1.5	2026-07-08 10:34:20.048
cmrd937xx0022undcvbkvlczd	81	6	45	1.5	2026-07-08 12:34:20.048
cmrd937xx0023undccttw1o7v	50	9	45	1.5	2026-07-08 14:34:20.048
cmrd937xx0024undcrw0iuc0i	80	6	45	1.5	2026-07-08 16:34:20.048
cmrd937xx0025undcx5aipg1s	37	9	45	1.5	2026-07-08 18:34:20.048
cmrd937xx0026undch2tgufg6	42	7	45	1.5	2026-07-08 20:34:20.048
cmrd937xx0027undcy8mm2q7o	39	6	45	1.5	2026-07-08 22:34:20.048
cmrd937xx0028undc7w6pjlvs	42	7	45	1.5	2026-07-09 00:34:20.048
cmrd937xx0029undcv0akfv43	37	9	45	1.5	2026-07-09 02:34:20.048
cmrd937xx002aundc6xx3xu9n	59	8	45	1.5	2026-07-09 04:34:20.048
cmrd937xx002bundc3oyak81f	69	12	45	1.5	2026-07-09 06:34:20.048
cmrda081y002cundca72senpg	32	62	33	0	2026-07-09 09:00:00.071
cmrdtao3x0000nkdcpsny2gp6	32	56	33	0	2026-07-09 18:00:00.142
cmrdvfvnz0000n0dcx6wty8qe	100	74	33	0.2	2026-07-09 19:00:02.447
cmrg0llu6000f4kdcxedp6jp8	16	60	33	0	2026-07-11 07:00:00.078
cmrg2qrm10000zvdch6yxxurp	37	52	33	0	2026-07-11 08:00:00.073
cmrgsgoxq0000zmdc76juvk5u	27	63	33	0	2026-07-11 20:00:00.062
cmrkd2bm30001hzdci3b06xau	37	64	33	0	2026-07-14 08:00:00.075
cmrkf7hdz0002hzdcpmvhuux5	18	62	33	0	2026-07-14 09:00:00.071
cmrkyhxgg000092dc6x43qjke	31	51	33	0	2026-07-14 18:00:00.16
cmrl0n3zj0000lrdcd1qwxsls	45	68	33	0	2026-07-14 19:00:01.136
cmrl2s8yl0000xfdc8tku9upj	37	67	33	0.1	2026-07-14 20:00:00.093
cmrlqd0i800000adcnc97kcqn	32	54	33	0	2026-07-15 07:00:00.081
cmrlsi6c300000jdcqk8rfo2p	38	68	33	0	2026-07-15 08:00:00.147
cmrlunc1w001dk4dcag5dj7n0	24	71	33	0	2026-07-15 09:00:00.068
cmrmg2xv10002modc6ns17lci	20	57	33	0	2026-07-15 19:00:00.109
cmrmi83ox0000b3dcibejk26d	21	70	33	0	2026-07-15 20:00:00.177
cmrmkd9e4000gwxdczg3c53ag	36	79	33	0.1	2026-07-15 21:00:00.076
cmrnvisk90007uydcy96ui1ax	38	65	33	0	2026-07-16 19:00:00.153
cmrnxnya40000dldc6ll0z8nc	35	62	33	0	2026-07-16 20:00:00.077
cmrnzt4200003j5dcz6cikrli	34	69	33	0	2026-07-16 21:00:00.072
cmrp08uct00026xdcxmb1yfv6	46	69	33	0.1	2026-07-17 14:00:00.173
cmrp2e0j600002qdcg0l4ydfk	31	76	33	0.1	2026-07-17 15:00:00.691
cmrp4j6di000031dcto8odbrs	34	75	33	0	2026-07-17 16:00:00.775
cmrpwe906000o9cdcfuel1l6r	55	62	33	0	2026-07-18 05:00:00.15
cmrpyjeq0000aphdc3w82grjo	48	61	33	0	2026-07-18 06:00:00.072
cmrq0okin000hphdc4uuyl8pm	49	61	33	0	2026-07-18 07:00:00.095
cmrq2tqba000089dca4o3rt9t	52	80	33	0	2026-07-18 08:00:00.119
cmrq4yw2e000789dcc8601066	49	76	33	0	2026-07-18 09:00:00.087
cmrqo9c1q0004u4dcm8nq8ac6	39	64	33	0	2026-07-18 18:00:00.062
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.system_settings (id, key, value, category, updated_at) FROM stdin;
cmrlqdrjm00050adc02ojdjus	emailDigest	false	notifications	2026-07-15 07:00:37.79
cmrmkhsw6000hwxdc1ljy1i4v	notifyTelegram	true	general	2026-07-15 21:07:27.423
cmrmhhyec0000ewdc2ysgrig3	telegramBotToken	8775067646:AAGQuqkm6B_lj8ZPkiLmg_AI_7CFr7C0WkU	general	2026-07-15 21:07:35.022
cmrmhhyee0001ewdcpoe3tjlg	telegramChatId	7253881576	general	2026-07-15 21:07:35.024
cmrozp9eg00009zdc54bn1dgd	serverName	Portdock CaaS	general	2026-07-17 13:44:46.552
cmrlr4l3r000a0adckp62g6m9	timezone	Asia/Jakarta	general	2026-07-17 13:44:46.555
cmrlr4l3s000b0adcpvg68078	language	en	general	2026-07-17 13:44:46.557
cmrlrbza3000s0adcletfhnw7	twoFactor	true	security	2026-07-15 08:14:59.877
cmrozp9en00039zdcr3gpcybl	maintenanceMode	true	system	2026-07-17 13:44:46.559
cmrlr4l3j00070adcy870ibh2	siteName	portdock	general	2026-07-15 09:05:41.886
cmrlr4l3n00080adcyb5b48bu	siteDesc	platform cloud hosting docker 	general	2026-07-15 09:05:41.89
cmrlr4l3p00090adctg2ckouz	adminEmail	develop@support.com	general	2026-07-15 09:05:41.892
cmrlr4l3t000c0adcizq0baf4	dateFormat	DD/MM/YYYY	general	2026-07-15 09:05:41.898
cmrlr4l3u000d0adc7pfiocc5	timeFormat	24h	general	2026-07-15 09:05:41.9
cmrlrbza6000t0adcsc8hpqez	sessionTimeout	15	security	2026-07-15 09:20:06.679
cmrlrbza9000u0adckbrkg6gs	loginAttempts	5	security	2026-07-15 09:20:06.682
cmrmgd3vs0003modchxmbkz67	pwdMinLength	8	general	2026-07-15 19:07:54.472
cmrmgd3vw0004modc5dpiegc6	pwdRequireUpper	true	general	2026-07-15 19:07:54.476
cmrmgd3w90005modclfst3sco	pwdRequireNumber	true	general	2026-07-15 19:07:54.489
cmrmgd3wc0006modc2alcr9v0	pwdRequireSpecial	true	general	2026-07-15 19:07:54.492
cmrlqdq5l00030adca8aukgat	notifyMaintenance	false	notifications	2026-07-17 13:59:40.524
cmrmj5cyp0000ptdcoyvbxitc	notifyDeployments	true	notifications	2026-07-15 20:25:52.723
cmrmj5f3s0002ptdc9ljsx73q	notifySystem	true	notifications	2026-07-15 20:25:55.531
cmrlqdoq200010adczol2rg6t	notifySecurity	true	notifications	2026-07-15 20:25:57.931
cmrmk5yie0000wxdcicc3jyhw	primaryColor	blue	appearance	2026-07-15 20:56:21.915
cmrmk5yif0001wxdcy1xrnbn5	sidebarStyle	default	appearance	2026-07-15 20:56:21.918
\.


--
-- Data for Name: terminal_logs; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.terminal_logs (id, user_id, project_id, command, output, executed_at) FROM stdin;
cmracgmrf0007sbdc3x13c8f9	cmqzg0qll0002w8dcorklsynq	cmrac8ac20001sbdcjtm15ofh	ls	\N	2026-07-07 07:45:26.331
cmracgox30008sbdco5u8mqb4	cmqzg0qll0002w8dcorklsynq	cmrac8ac20001sbdcjtm15ofh	l	\N	2026-07-07 07:45:29.128
cmracgrir0009sbdc0uraytx5	cmqzg0qll0002w8dcorklsynq	cmrac8ac20001sbdcjtm15ofh	nginx -v	\N	2026-07-07 07:45:32.499
cmqzcwk6g00004zdcdr5m00e0	cmqtq4ojw00003odcvi7bopj5	\N	la	\N	2026-06-29 15:12:21.544
cmqzcwkwn00014zdc57fvtx4a	cmqtq4ojw00003odcvi7bopj5	\N	ls	\N	2026-06-29 15:12:22.487
cmqzcwnvb00024zdcgys6fisk	cmqtq4ojw00003odcvi7bopj5	\N	cat Doc	\N	2026-06-29 15:12:26.327
cmqzcwrbv00034zdcpy8lfsfl	cmqtq4ojw00003odcvi7bopj5	\N	cat inde	\N	2026-06-29 15:12:30.811
cmqwt56nf000e5jdc01qxh1bu	cmqtq4ojw00003odcvi7bopj5	\N	apache -v	\N	2026-06-27 20:23:39.243
cmqwt5aws000f5jdc9wjez75r	cmqtq4ojw00003odcvi7bopj5	\N	ersion	\N	2026-06-27 20:23:44.764
cmqwt5c9p000g5jdcczlpib0t	cmqtq4ojw00003odcvi7bopj5	\N	nginx -v	\N	2026-06-27 20:23:46.525
cmqwt7tg900003ldcfu89xh9f	cmqtq4ojw00003odcvi7bopj5	\N	apache -v	\N	2026-06-27 20:25:42.106
cmqwtap7g00043ldcjiggk19i	cmqtq4ojw00003odcvi7bopj5	\N	l	\N	2026-06-27 20:27:56.572
cmqwtaqm400053ldcpenpybkf	cmqtq4ojw00003odcvi7bopj5	\N	clear	\N	2026-06-27 20:27:58.397
cmqwtay6j00063ldca2g5a8dg	cmqtq4ojw00003odcvi7bopj5	\N	whoami	\N	2026-06-27 20:28:08.203
cmqwtbqej00093ldc3ypnanvm	cmqtq4ojw00003odcvi7bopj5	\N	apache -v	\N	2026-06-27 20:28:44.779
cmqwtcce0000a3ldcidik59ex	cmqtq4ojw00003odcvi7bopj5	\N	apache2 -v	\N	2026-06-27 20:29:13.272
cmqwtcqfb000b3ldcyn0j7c22	cmqtq4ojw00003odcvi7bopj5	\N	V	\N	2026-06-27 20:29:31.463
cmqwtcujm000c3ldc0cjxxjuj	cmqtq4ojw00003odcvi7bopj5	\N	httpd -v	\N	2026-06-27 20:29:36.802
cmqwtdpoy000d3ldcnij2zcfh	cmqtq4ojw00003odcvi7bopj5	\N	ls	\N	2026-06-27 20:30:17.17
cmqwtdw4b000e3ldcd5cvxmzo	cmqtq4ojw00003odcvi7bopj5	\N	cd buil	\N	2026-06-27 20:30:25.499
cmqwtdwg5000f3ldclvwlt1ru	cmqtq4ojw00003odcvi7bopj5	\N	l	\N	2026-06-27 20:30:25.925
cmqwtdy4v000g3ldc5shbpbuu	cmqtq4ojw00003odcvi7bopj5	\N	ls	\N	2026-06-27 20:30:28.111
cmqwte10w000h3ldcmr7j9j41	cmqtq4ojw00003odcvi7bopj5	\N	cd ..	\N	2026-06-27 20:30:31.856
cmqwte1ba000i3ldceim55h64	cmqtq4ojw00003odcvi7bopj5	\N	l	\N	2026-06-27 20:30:32.23
cmqwte28d000j3ldcp3odj3k3	cmqtq4ojw00003odcvi7bopj5	\N	ls	\N	2026-06-27 20:30:33.421
cmqwte5a6000k3ldcf15a00nm	cmqtq4ojw00003odcvi7bopj5	\N	cd htdo	\N	2026-06-27 20:30:37.374
cmqwte5xn000l3ldc8gyb8p6m	cmqtq4ojw00003odcvi7bopj5	\N	ls	\N	2026-06-27 20:30:38.219
cmqwte8fo000m3ldcz86arvz6	cmqtq4ojw00003odcvi7bopj5	\N	cat inde	\N	2026-06-27 20:30:41.46
cmqwte9xw000n3ldcm2qy4y4t	cmqtq4ojw00003odcvi7bopj5	\N	clear	\N	2026-06-27 20:30:43.412
cmqwtbf3200073ldce5qheixg	cmqtq4ojw00003odcvi7bopj5	\N	apache -v	\N	2026-06-27 20:28:30.111
cmqwtbh4d00083ldc14almxuc	cmqtq4ojw00003odcvi7bopj5	\N	nginx -v	\N	2026-06-27 20:28:32.749
cmroyuei00002r1dcs92xz49d	cmqtq4ojw00003odcvi7bopj5	\N	ls	\N	2026-07-17 13:20:46.824
cmroyujfi0003r1dceirfl9c4	cmqtq4ojw00003odcvi7bopj5	\N	nginx -v	\N	2026-07-17 13:20:53.215
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: portdock
--

COPY public.users (id, name, email, password, created_at, updated_at, "githubToken", "githubUsername", "sshPrivateKey", "sshPublicKey", role, last_login, status, failed_login_attempts, is_two_factor_enabled, lockout_until, two_factor_secret) FROM stdin;
cmqtq4ojw00003odcvi7bopj5	develop	develop@support.com	$2b$12$RMYHI444xQ9YJnVBnsg9vOfqFRBLCesCsbz3kC8SOoljhZuwXi6bS	2026-06-25 16:35:58.412	2026-07-17 13:45:03.338	\N	\N	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACD0QE+5JvozCY6ObKuIQU/VKMc9k42OAKTuyDeUStLY1QAAAKhNOqFYTTqh\nWAAAAAtzc2gtZWQyNTUxOQAAACD0QE+5JvozCY6ObKuIQU/VKMc9k42OAKTuyDeUStLY1Q\nAAAEBZVyrUkNVPtz7GLTr3lP2Vs4A4oFExAONvptqxJ6v2kfRAT7km+jMJjo5sq4hBT9Uo\nxz2TjY4ApO7IN5RK0tjVAAAAInBvcnRkb2NrX2NtcXRxNG9qdzAwMDAzb2Rjdmk3Ym9waj\nUBAgM=\n-----END OPENSSH PRIVATE KEY-----\n	ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPRAT7km+jMJjo5sq4hBT9Uoxz2TjY4ApO7IN5RK0tjV portdock_cmqtq4ojw00003odcvi7bopj5	ADMIN	2026-07-17 13:45:03.332	ACTIVE	0	f	\N	\N
cmr54o1v600013wdcd40fjyhs	john1	john@example.com	$2b$12$LqdR7FLUL.pS8Fa7lpTFneoPSc2UU9mT/oFa5KOzbyPZlswM2IkdC	2026-07-03 16:08:24.69	2026-07-03 16:16:15.154	\N	\N	\N	\N	USER	\N	SUSPENDED	0	f	\N	\N
cmqzg0qll0002w8dcorklsynq	user1	user1@gmail.com	$2b$12$jKvpBpjFZyKXn1gUK7ltv.XfAiaoiDCe48KouzW.T2gHVfxPIkYBO	2026-06-29 16:39:35.337	2026-07-15 18:06:32.02	\N	\N	\N	\N	USER	2026-07-15 18:06:31.958	ACTIVE	0	f	\N	\N
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: containers containers_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.containers
    ADD CONSTRAINT containers_pkey PRIMARY KEY (id);


--
-- Name: deployments deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_pkey PRIMARY KEY (id);


--
-- Name: managed_databases managed_databases_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.managed_databases
    ADD CONSTRAINT managed_databases_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: terminal_logs terminal_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.terminal_logs
    ADD CONSTRAINT terminal_logs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: containers_docker_container_id_key; Type: INDEX; Schema: public; Owner: portdock
--

CREATE UNIQUE INDEX containers_docker_container_id_key ON public.containers USING btree (docker_container_id);


--
-- Name: managed_databases_docker_container_id_key; Type: INDEX; Schema: public; Owner: portdock
--

CREATE UNIQUE INDEX managed_databases_docker_container_id_key ON public.managed_databases USING btree (docker_container_id);


--
-- Name: system_settings_key_key; Type: INDEX; Schema: public; Owner: portdock
--

CREATE UNIQUE INDEX system_settings_key_key ON public.system_settings USING btree (key);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: portdock
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: activity_logs activity_logs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: containers containers_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.containers
    ADD CONSTRAINT containers_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deployments deployments_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: managed_databases managed_databases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.managed_databases
    ADD CONSTRAINT managed_databases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: terminal_logs terminal_logs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.terminal_logs
    ADD CONSTRAINT terminal_logs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: terminal_logs terminal_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: portdock
--

ALTER TABLE ONLY public.terminal_logs
    ADD CONSTRAINT terminal_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict qdBbjToHodMD6e03lnAqTsvWR75FWPbPG4VLIyxDlgxocWbuNZuOPH1RK4aEgg7

